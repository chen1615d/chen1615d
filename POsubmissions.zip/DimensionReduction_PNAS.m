%clear;

% Copyright: Zhengjun Zhang, University of Wisconsin, CDIS
% Description: This program of dimension reduction is for the research use.
% It shouldn't be used for commercial purpose by anyone else. 
% Anyone else who directly or indirectly uses the program and the idea or modifies the
% program should acknowledge the contribution of the author, i.e., Zhengjun Zhang and the paper he coauthored. 

m1 = 40; 
m0 = 22;

T=load('Tcolon');    % tumor group sample size 40 genes 1991
N=load('Ncolon');    % normal group sample size 22 genes 1991

% T = T.^2; %without .^2 to generate s0
% N = N.^2;

for i=1:1991
    tm = mean(T(i,:));
    nm = mean(N(i,:));
    tv = std(T(i,:));
    nv = std(N(i,:));
    ts = tv/tm;
    ns = nv/nm;
    Cm(i) = abs((tm-nm)/nm);
    Cv(i) = abs((tv-nv)/nv);
    Cs(i) = abs((ts-ns)/ns);
end
[Scm, Icm] = sort(Cm);
[Scv, Icv] = sort(Cv);
[Scs, Ics] = sort(Cs);


Jm = Icm(1:19); Jm = sort(Jm); % 1%
Jv = Icv(1693:1991); Jv = sort(Jv);% 85%
Js = Ics(1892:1991); %Js = sort(Js); % 5% 

s = [];

thr = 0.5;
for i=1:100
    tt = T(Js(i),:);
    tm = mean(tt);
    nm = mean(N(Js(i),:));
    nmax = max(N(Js(i),:));
    nmin = min(N(Js(i),:));
    if tm>nm
        Imax = find(tt>nmax);
        sen = length(Imax)/40;
        if sen > thr
           s = [s Js(i)];
        end
    else
        Imin = find(tt<nmin);
        sen = length(Imin)/40;
        if sen > thr
           s = [s Js(i)];
        end
    end
end


thr = 0.7;
for i=1:19
    tt = T(Jm(i),:);
    tm = mean(tt);
    nm = mean(N(Jm(i),:));
    nmax = max(N(Jm(i),:));
    nmin = min(N(Jm(i),:));
    if tm>nm
        Imax = find(tt>nmax);
        sen = length(Imax)/40;
        if sen > thr
           s = [s Jm(i)];
        end
    else
        Imin = find(tt<nmin);
        sen = length(Imin)/40;
        if sen > thr
           s = [s Jm(i)];
        end
    end
end
thr = 0.8;
for i=1:299
    tt = T(Jv(i),:);
    tm = mean(tt);
    nm = mean(N(Jv(i),:));
    nmax = max(N(Jv(i),:));
    nmin = min(N(Jv(i),:));
    if tm>nm
        Imax = find(tt>nmax);
        sen = length(Imax)/40;
        if sen > thr
           s = [s Jv(i)];
        end
    else
        Imin = find(tt<nmin);
        sen = length(Imin)/40;
        if sen > thr
           s = [s Jv(i)];
        end
    end
end

s= sort(s)';
return
% s0 from T and N directly
sfinal = [];
for i=1:88,
    Ifinal = find(s0 == s(i));
    if ~isempty(Ifinal);
        sfinal = [sfinal s(i)];
    end
end
